# __init__.py
"""
Prediction of protein subcellular localization
"""
from . import deeploc2
from . import model
from . import data
from . import attr_prior
